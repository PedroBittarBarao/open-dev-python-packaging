# pacote_ericalp

Pacote genérico para aula de Open Source

Repositório da disciplina : https://github.com/Insper/open-dev